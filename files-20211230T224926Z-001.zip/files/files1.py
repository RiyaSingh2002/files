f=open("exercise.txt")
file_data=f.read()
print(file_data)
f.close()
