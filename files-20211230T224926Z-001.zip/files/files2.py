f=open("exercise.txt")
file_data=f.readlines()
print(file_data)
f.close()
 